/**
 * Autor: Gonzalo Santiago Garcia
 * Fecha de Creación: 22/03/2023
 * Fecha de Actualización: 22/03/2023
 * Descripción:  Programa Java que muestre los números
 * 			     del 1 al 100 utilizando la instrucción for
 */
package tareasPoo2_2023;

public class Ejercicio39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	for(int i=1; i<=100;i++) {
		System.out.println(i);
	}

	}

}
