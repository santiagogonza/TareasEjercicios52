/**
 * Autor: Gonzalo Santiago Garcia
 * Fecha de Creación: 22/03/2023
 * Fecha de Actualización: 22/03/2023
 * Descripción: Programa Java que muestre los números 
 * 				del 1 al 100 utilizando la instrucción while
 **************************************************************/
package tareasPoo2_2023;

public class Ejercicio37 {
	public static void main(String[] args) {
		int i =1;
		while(i<=100) {
			System.out.println(i);
			i++;
		}
	}
}
