/**
 * Autor: Gonzalo Santiago Garcia
 * Fecha de Creación: 22/03/2023
 * Fecha de Actualización: 22/03/2023
 * Descripción: Programa Java que muestre los números 
 * 				del 100 al 1 utilizando la instrucción do..while
 */

package tareasPoo2_2023;

public class Ejercicio41 {
	public static void main(String[] args) {
		 int i =100;
        do {
            System.out.println(i);
            i--;
        } while (i >= 1);
    
	}

}
