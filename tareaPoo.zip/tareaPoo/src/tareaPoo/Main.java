package tareaPoo;

public class Main {

	public static void main(String[] args) {
		
		Mascota perro = new Mascota("Fido", 3, "Juan");
		Mascota gato = new Mascota("Michi", 2, "Ana");
		Persona persona = new Persona("Pedro");
		persona.agregarMascota(perro);
		persona.agregarMascota(gato);
		persona.alimentarMascotas();

	}

}
