package tareaPoo;

import java.util.ArrayList;
import java.util.List;

public class Persona {
	
	   private String nombre;
	   private List<Mascota> mascotas;
	   
	   // constructor
	   public Persona(String nombre) {
	      this.nombre = nombre;
	      this.mascotas = new ArrayList<>();
	   }
	   
	   public void agregarMascota(Mascota mascota) {
	      mascotas.add(mascota);
	   }
	   
	   public void alimentarMascotas() {
	      for (Mascota mascota : mascotas) {
	         mascota.comer();
	      }
	   }
	   
	   public String getNombre() {
	      return nombre;
	   }
	   
	   public List<Mascota> getMascotas() {
	      return mascotas;
	   }
}
