package tareaPoo;

public class Animal {

	private String nombre;
	   private int edad;
	   
	   // constructor
	   public Animal(String nombre, int edad) {
	      this.nombre = nombre;
	      this.edad = edad;
	   }
	   
	   public void comer() {
	      System.out.println(nombre + " está comiendo");
	   }
	   
	   public void dormir() {
	      System.out.println(nombre + " está durmiendo");
	   }
	   
	   public String getNombre() {
	      return nombre;
	   }
	   
	   public int getEdad() {
	      return edad;
	   }
	}
