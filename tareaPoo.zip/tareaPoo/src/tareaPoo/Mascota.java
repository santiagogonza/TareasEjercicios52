package tareaPoo;

public class Mascota extends Animal {
	private String duenio;
	   
	   // constructor
	   public Mascota(String nombre, int edad, String duenio) {
	      super(nombre, edad);
	      this.duenio = duenio;
	   }
	   
	   public void jugar() {
	      System.out.println(getNombre() + " está jugando con " + duenio);
	   }
	   
	   public String getDuenio() {
	      return duenio;
	   }
}
